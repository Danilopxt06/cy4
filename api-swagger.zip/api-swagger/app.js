const express = require('express');
const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('./swagger');
const app = express();
const PORT = 3000;
app.use(express.json());
let produtos = [
    { id: 1, nome: 'Teclado', preco: 120 },
    { id: 2, nome: 'Mouse', preco: 80 }
];
let proximoId = 3;
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
/**
 * @openapi
 * /produtos:
 *   get:
 *     tags: [Produtos]
 *     summary: Lista todos os produtos
 *     responses:
 *       200:
 *         description: Lista de produtos
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Produto'
 */
app.get('/produtos', (req, res) => {
    res.status(200).json(produtos);
});
/**
 * @openapi
 * /produtos/{id}:
 *   get:
 *     tags: [Produtos]
 *     summary: Busca um produto pelo ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Produto encontrado
 *       404:
 *         description: Produto não encontrado
 */
app.get('/produtos/:id', (req, res) => {
    const id = Number(req.params.id);
    const produto = produtos.find((item) => item.id === id);
    if (!produto) {
        return res.status(404).json({ mensagem: 'Produto não encontrado.' });
    }
    res.status(200).json(produto);
});
/**
 * @openapi
 * /produtos:
 *   post:
 *     tags: [Produtos]
 *     summary: Cadastra um produto
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/NovoProduto'
 *           example:
 *             nome: "Monitor"
 *             preco: 900
 *     responses:
 *       201:
 *         description: Produto criado
 *       400:
 *         description: Dados inválidos
 */
app.post('/produtos', (req, res) => {
    const { nome, preco } = req.body;
    if (!nome || preco === undefined) {
        return res.status(400).json({
            mensagem: 'nome e preco são obrigatórios.'
        });
    }
    const novoProduto = {
        id: proximoId++,
        nome,
        preco: Number(preco)
    };
    produtos.push(novoProduto);
    res.status(201).json(novoProduto);
});
/**
 * @openapi
 * /produtos/{id}:
 *   put:
 *     tags: [Produtos]
 *     summary: Atualiza um produto
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/NovoProduto'
 *           example:
 *             nome: "Monitor Full HD"
 *             preco: 950
 *     responses:
 *       200:
 *         description: Produto atualizado
 *       404:
 *         description: Produto não encontrado
 */
app.put('/produtos/:id', (req, res) => {
    const id = Number(req.params.id);
    const indice = produtos.findIndex((item) => item.id === id);
    if (indice === -1) {
        return res.status(404).json({ mensagem: 'Produto não encontrado.' });
    }
    const { nome, preco } = req.body;
    produtos[indice] = {
        id,
        nome,
        preco: Number(preco)
    };
    res.status(200).json(produtos[indice]);
});
/**
 * @openapi
 * /produtos/{id}:
 *   delete:
 *     tags: [Produtos]
 *     summary: Exclui um produto
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       204:
 *         description: Produto excluído
 *       404:
 *         description: Produto não encontrado
 */
app.delete('/produtos/:id', (req, res) => {
    const id = Number(req.params.id);
    const indice = produtos.findIndex((item) => item.id === id);
    if (indice === -1) {
        return res.status(404).json({ mensagem: 'Produto não encontrado.' });
    }
    produtos.splice(indice, 1);
    res.status(204).send();
});

/**
 * @openapi
 * /categorias:
 *   get:
 *     tags: [Categorias]
 *     summary: Lista as categorias
 *     responses:
 *       200:
 *         description: Lista de categorias
 */
app.get('/categorias', (req, res) => {
    const categorias = [
        { id: 1, nome: 'Periféricos' },
        { id: 2, nome: 'Monitores' },
        { id: 3, nome: 'Acessórios' }
    ];
    res.status(200).json(categorias);
});

app.listen(PORT, () => {
    console.log(`API rodando em http://localhost:${PORT}`);
    console.log(`Swagger UI em http://localhost:${PORT}/api-docs`);
});