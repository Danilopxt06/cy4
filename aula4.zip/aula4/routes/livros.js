const mongoose = require('mongoose');

mongoose.conect('mongodb://127.0.0.1:27017/biblioteca')
.then(() => console.log('Conectado ao MongoDB!'))
.catch((erro) => console.log('Erro ao conectar!', erro));

const express = require('express');
const router = express.Router();
const Livro = ('../models/Livro');

router.post('/livros', async (req, res) => {
    try{
        const novoLivro = new Livro(req.body);
        const livroSalvo = await novoLivro.save();
        res.status(201).json(livroSalvo);
    }
    catch (erro){
        res.status(400).json({ mensagem: 'Erro ao CRIAR esse Livro!'});
    }
});

router.get('/livros', async (req, res) => {
    try{
        const livros = await Livro.find();
        res.status(200).json(livros);
    }
    catch (erro){
        res.status(500).json({ mensagem: 'Erro ao BUSCAR esse Livro!'});
    }
});

const livrosRoutes = require('./routes/livros');
app.use('/api', livrosRoutes);