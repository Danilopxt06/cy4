const swaggerJSDoc = require('swagger-jsdoc');
const options = {
    definition: {
        openapi: '3.0.3',
        info: {
            title: 'API de Produtos - Aula de Swagger',
            version: '1.0.0',
            description: 'API simples criada do zero para demonstrar OpenAPI e Swagger UI.'
        },
        servers: [
            {
                url: 'http://localhost:3000'
            }
        ],
        tags: [
            {
                name: 'Produtos',
                description: 'Operações de produtos'
            }
        ],
        components: {
            schemas: {
                Produto: {
                    type: 'object',
                    required: ['id', 'nome', 'preco'],
                    properties: {
                        id: {
                            type: 'integer',
                            example: 1
                        },
                        nome: {
                            type: 'string',
                            example: 'Teclado'
                        },
                        preco: {
                            type: 'number',
                            example: 120
                        }
                    }
                },
                NovoProduto: {
                    type: 'object',
                    required: ['nome', 'preco'],
                    properties: {
                        nome: {
                            type: 'string',
                            example: 'Monitor'
                        },
                        preco: {
                            type: 'number',
                            example: 900
                        }
                    }
                }
            }
        }
    },
    apis: ['./app.js'],
    failOnErrors: true
};
module.exports = swaggerJSDoc(options);