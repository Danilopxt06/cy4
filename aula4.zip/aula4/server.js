
const express = require('express');
const app = express();
app.use(express.json());

    app.get("/divide", (req, res) => {
        try{
            const numerador = 10;
            const denominador = 2;
            if (denominador === 0){
                res.status(400).json({ error: "Não é possível dividir"});
            }
            const resultado = numerador/denominador;
            res.json({resultado})
        }
        catch (err){
            res.status(400).json({ error: err.message});
        }
    });

app.listen(3000, () => console.log("Server rodando na porta 3000"));